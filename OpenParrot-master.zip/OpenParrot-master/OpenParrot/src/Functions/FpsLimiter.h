#include <StdInc.h>

void FpsLimiterSet(float fFPSLimit);
void FpsLimiter();