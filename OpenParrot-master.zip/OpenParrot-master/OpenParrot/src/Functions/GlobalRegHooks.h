#pragma once
void init_GlobalRegHooks();