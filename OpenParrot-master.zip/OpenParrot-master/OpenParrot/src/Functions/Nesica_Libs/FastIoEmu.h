#pragma once
void init_FastIoEmu();