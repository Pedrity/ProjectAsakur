#pragma once
void init_RegHooks();