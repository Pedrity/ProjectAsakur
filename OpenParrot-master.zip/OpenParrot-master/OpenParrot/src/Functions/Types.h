enum class X2Type {
	None,
	RFID,
	Digital,
	Analog,
	VRL,
	Raiden4,
	BG4,
	Lupin3,
	Generic,
	GaiaAttack4,
	BattleFantasia,
	MB4,
	Wontertainment,
	BG4_Eng,
	BlazBlue,
	ElevatorActionDeathParade
};