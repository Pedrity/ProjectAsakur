#pragma once
int init_libacioHooks();