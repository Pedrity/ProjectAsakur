#pragma once
int init_libavs();