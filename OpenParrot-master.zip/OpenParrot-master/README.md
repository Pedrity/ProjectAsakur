# OpenParrot-Asakura
Hyperspecialised fork of OpenParrot for Wangan Midnight Maximum Tune.

## Disclaimer
Please do not ask me to contribute to the TeknoParrot project. I will decline. I will only reconsider if you make the ENTIRETY of TeknoParrot COMPLETELY open-source.

## How to use
Don't, yet. (But you'd be able to use it with TeknoParrotUI or something.)

## Special thanks
 - [Emi (PockyWitch)](https://twitter.com/ChocomintPuppy) - code, protocol analysis, info etc
 - [derole](https://derole.co.uk) - protocol help, info
 - [The Wangan Midnight Emulation Discord](https://discord.gg/r3nbd4x) - being the reason I started doing this in the first place